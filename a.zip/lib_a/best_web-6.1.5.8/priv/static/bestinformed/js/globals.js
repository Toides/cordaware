"use strict";

// Compiles required for IE, which has no idea what ES6 is.

// See uncompiled JS here: https://gist.github.com/Patrick-Sachs/006bc15c679b1e80ddf7abe92aa0c25f
function getLang(){return"@lg_this_lang@"}
function openFrameHelper(){var f=this,a=[].concat(Array.prototype.slice.call(arguments)).find(function(h){return h.biHelpPageGerman}),b="german"===getLang()?a.biHelpPageGerman:a.biHelpPageEnglish;if(a.biHelpIsDropdown){var c=Object.keys(b).map(function(h){return{text:h,iconCls:"fa fa-question fa-2x",biHelpPageGerman:a.biHelpPageGerman[h],biHelpPageEnglish:a.biHelpPageEnglish[h]}}),d=Ext.create("Ext.menu.Menu",{items:c});d.on("click",function(h,i){f.openFrameHelper(i)}),d.showBy(a,"tr-br?")}else{var g=("german"===getLang()?"https://www.cordaware.com/help_german/":"https://www.cordaware.com/help_english/")+b;Ext.create("Ext.window.Window",{title:g,height:"80%",width:"80%",layout:"fit",items:{html:"<iframe src=\""+encodeURI(g)+"\" width=\"100%\" height=\"100%\">@lg_loading@</iframe>",xtype:"panel",reference:"frame",anchor:"100% 100%"}}).show()}}
function createFrameHelper(a,b){return{type:"help",tooltip:"@lg_help@",tooltipType:"qtip",biHelpIsDropdown:"string"!=typeof a,biHelpPageGerman:a,biHelpPageEnglish:b,handler:"openFrameHelper",scope:window}}

// See uncompiled JS here: https://gist.github.com/Patrick-Sachs/2b8969891104ab724eff940c74466d27
function formatUnicorn(str, values){return Object.keys(values).reduce(function(str, k){return str.replace("{" + k + "}", values[k]);},str);}; //🦄

// fix for IE
window.formatUnicorn = formatUnicorn;
window.openFrameHelper = openFrameHelper;
window.createFrameHelper = createFrameHelper;
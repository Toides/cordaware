// GUI for Survey Application
// declare the namespace for the survey app
var Survey = {};
/**
 *
 * The **GraphicalEditor** is responsible for layout and dialog handling.
 * @extends draw2d.ui.parts.GraphicalEditor
 */
Survey.Application = Class.extend(
    {
        NAME : "Survey.Application",

        /**
         * @constructor
         *
         * @param {String} canvasId the id of the DOM element to use as paint container
         */
        checkStruct:{start:false,end:false},
        init : function()
        {
            this.view    = new Survey.View("canvas");
            this.toolbar = new Survey.Toolbar("toolbar", this.view );
        },
        setStructurCheck:function(figure,input){
            this.checkStruct[figure] = input;
            return true;
        },
        getStructurCheck:function(figure){
            return this.checkStruct[figure];
        },
        clearStructurCheck:function(){
            this.checkStruct.start = false;
            this.checkStruct.end= false;
        }
    });
//Toolbar

Survey.Toolbar = Class.extend({

    init:function(elementId, view){
        this.html = $("#"+elementId);
        this.view = view;

        // register this class as event listener for the canvas
        // CommandStack. This is required to update the state of
        // the Undo/Redo Buttons.
        //
        view.getCommandStack().addEventListener(this);

        // Register a Selection listener for the state handling
        // of the Delete Button
        //
        view.on("select", $.proxy(this.onSelectionChanged,this));

    },
    doUndo:function(){
        this.view.getCommandStack().undo();
    },
    doRedo:function(){
        this.view.getCommandStack().redo();
    },
    doDelete:function(){
        var node = this.view.getCurrentSelection();
        if(node.deleteable){
            var command= new draw2d.command.CommandDelete(node);
            this.view.getCommandStack().execute(command);
        }
    },
    doZoomIn: function() {
        this.view.setZoom(this.view.getZoom()*0.7,true);
    },
    doZoomOut: function() {
        this.view.setZoom(this.view.getZoom()*1.3, true);
    },
    doZoom1To1: function() {
        this.view.setZoom(1.0, true);
    },
    doSave:function(){
        var writer = new draw2d.io.json.Writer();
        var data;
        writer.marshal(this.view,function(json){
            data = JSON.stringify(json, null, 2);
        });
        return (data);
    },
    editQuestion: function() {
        var node = this.view.getCurrentSelection();
        if (node !=null && node.isQuestion === true && !(node.id == 'start' || node.id == 'end')) {
            Bi.app.fireEvent('draweditquestion', node);
        }
    },
    copyQuestion: function() {
        var node = this.view.getCurrentSelection();
        if (node !=null && node.isQuestion === true && !(node.id == 'start' || node.id == 'end')) {
            Bi.app.fireEvent('drawcopyquestion', node);
        }
    },
    deleteQuestion: function() {
        var node = this.view.getCurrentSelection();
        if (node !=null && node.isQuestion === true && !(node.id == 'start' || node.id == 'end')) {
            Bi.app.fireEvent('drawdeletequestion', node);
        }
    },

    previewQuestion: function() {
        var node = this.view.getCurrentSelection();
        if (node !=null && node.isQuestion === true && !(node.id == 'start' || node.id == 'end')) {
            Bi.app.fireEvent('drawpreviewquestion', node);
        }
    },

    /**
     * @method
     * Called if the selection in the cnavas has been changed. You must register this
     * class on the canvas to receive this event.
     *
     * @param {draw2d.Figure} figure
     */
    onSelectionChanged: function(emitter, figure){
    },

    /**
     * @method
     * Sent when an event occurs on the command stack. draw2d.command.CommandStackEvent.getDetail()
     * can be used to identify the type of event which has occurred.
     *
     * @template
     *
     * @param {draw2d.command.CommandStackEvent} event
     **/
    stackChanged:function(event)
    {
        this.disableButton('btn_undo_routing', !event.getStack().canUndo());
        this.disableButton('btn_save_routing', !event.getStack().canUndo());
        this.disableButton('btn_redo_routing', !event.getStack().canRedo());
    },
    disableButton:function(button, flag)
    {
        Ext.getCmp(button).setDisabled(flag);
    }


});
//View
Survey.View = draw2d.Canvas.extend({

    init:function(id){
        this._super(id, $(window).width()-50,3000);

        this.getCommandStack().addEventListener(function(e){
            setTimeout(function(){
                if(e.command.connection !== null && e.command.connection !== undefined)
                    e.command.connection.toBack();
            },300);
        });

        this.setScrollArea('#'+id);
    }
});
//Struct
//Diamond
Survey.BranchingStruct = draw2d.shape.basic.Diamond.extend({

    NAME: "Survey.BranchingStruct",
    createid:'',
    init : function(attr)
    {
        this._super($.extend({bgColor:"#3b679e", color:"#d7d7d7",width:130, height:130,stroke:1, radius:3,resizeable:false},attr));

        this.classLabel = new draw2d.shape.basic.Label({
            text:"Verzweigung",
            stroke:0,
            fontColor:"#4a4a4a",
            radius: this.getRadius(),
            padding:30,
            width:130,
            resizeable:true,
            height:30
        });
        var locator =  new draw2d.layout.locator.CenterLocator();
        var input = this.classLabel.createPort("input");
        input.setName("input_"+this.id);
        input.onConnect = function(connection){
            var thisInputName =	this.parent.parent.y;
            var conOutputName = connection.sourcePort;
            //if(conOutputName.parent.parent.y >= thisInputName){
            //connection.setTarget(connection.oldTarget);
            //alert('@lg_no_connection_on_same_label@');
            //}
        };
        //console.log(Survey.Application);
        var output = this.classLabel.createPort("output");
        output.onConnect = function(connection){
            connection.setColor("#ff8000");
        };
        output.onDisconnect = function(connection){
            connection.oldSource = connection.getSource();
            connection.oldTarget = connection.getTarget();
        };
        this.add(this.classLabel,locator);

    },
    setPersistentAttributes : function(memento)
    {
    }

});

//Connection
/**
 * @author markus.schlede
 */
Survey.Connection = draw2d.Connection.extend({

    NAME:"Survey.Connection",
    bgColor:'#ff0000',

    init : function(attr)
    {
        this._super($.extend({stroke:2},attr));
        this.tooltip = null;
        this.setSourceDecorator(new draw2d.decoration.connection.CircleDecorator(10,10));
        this.setTargetDecorator(new draw2d.decoration.connection.ArrowDecorator());
        this.createLabelforConnection('');
        this.setRouter(draw2d.Connection.DEFAULT_ROUTER);
    },
    setPersistentAttributes : function(memento){

        var newtext = '';
        if(memento.userData.description !== '' && memento.userData.description !== undefined){
            newtext = memento.userData.description;
        }
        this.children.data[0].figure.setText(newtext);

        this.setUserData({"description":memento.description});
        this.toBack();


    },
    onDoubleClick:function(){
        this.children.data[0].figure.editor.start(this.children.data[0].figure);
    },
    createLabelforConnection:function(newtext){
        var me = this;
        var label = new draw2d.shape.basic.Label({text:newtext});
        label.setColor(null);


        /* no double click on label connection
         label.installEditor(new draw2d.ui.LabelInplaceEditor({
         // called after the value has been set to the LabelFigure
         onCommit: $.proxy(function(value){
         me.setUserData({"description":value});
         },this),
         // called if the user abort the operation
         onCancel: function(){
         }
         }));

         */


        label.setFontColor("#0d0d0d");
        var locator = new draw2d.layout.locator.ParallelMidpointLocator();
        this.add(label,locator);
    }

});

// display a context menu for routing

Survey.ContextMenuRouting = function(_table,emitter, event) {
    $.contextMenu({
        selector: 'body',
        events:
            {
                hide:function(){ $.contextMenu( 'destroy' ); }
            },
        callback: $.proxy(function(key, options)
        {
            switch(key){
                case "set_routing":
                    Survey.ContextMenuSetRouting(_table,emitter, event);
                    break;
                default:
                    break;
            }

        },this),
        x:event.x,
        y:event.y,
        items:
            {
                "set_routing":{name:"@lg_survey_set_routing@"}
            }
    });
};





//Survey Start

Survey.StartStruct = draw2d.shape.layout.VerticalLayout.extend({

    NAME: "Survey.StartStruct",
    createid:'',
    init : function(attr)
    {

        if(!SurveyDraw.getStructurCheck('start')){
            this._super($.extend({bgColor:"#3b679e", color:"#ffffff",cssClass:'white-border',stroke:1, radius:3},attr));

            this.classLabel = new draw2d.shape.basic.Label({
                text:"ClassName",
                stroke:0,
                bold:true,
                fontColor:"#ffffff",
                bgColor:"#3b679e",
                radius: this.getRadius(),
                padding:15,
                resizeable:true
            });
            var me = this;
            this.setVisible(false);
            this.repaintBlocked = false;
            this.setDeleteable( false );
            this.createid = this.id;
            this.classLabel.on("contextmenu", function(emitter, event){
                _table.openContextMenuLabel(_table,emitter, event);
            });

            var  ddPolicy = new draw2d.policy.figure.DragDropEditPolicy();
            //var input = this.classLabel.createPort("input");
            //input.setName("input_"+this.id);
            var output = this.classLabel.createPort("output");
            output.setName("output_"+this.id);
            output.on("contextmenu", function(emitter, event){
                // console.log(emitter);
                Survey.ContextMenuRouting(_table,emitter, event);
                //_table.openContextMenu(_table,emitter, event);
            });
            output.onConnect = function(connection){
                connection.setColor("#ff8000");

                //var thisOutputName =	this.parent.classLabel.inputPorts.data[0].name;
                //var conOutputName = connection.targetPort.name;
                if(this.connections.data[1] !== undefined){
                    connection.setSource(connection.oldSource);
                    alert('@lg_already_have_connection@');
                }
                /*if(conOutputName === thisOutputName){
                 connection.setSource(connection.oldSource);
                 alert('Die Quelle darf nicht beim selben Ziel angeschlossen werden');
                 }*/
            };
            output.onDisconnect = function(connection){
                connection.oldSource = connection.getSource();
                connection.oldTarget = connection.getTarget();
            };
            this.installEditPolicy(new draw2d.policy.figure.HorizontalEditPolicy());
            var _table = this;
            this.add(this.classLabel);

        }else{
            this._super();
            this.removeItem= true;
        }

    },

    /**
     * @method
     * Add an entity to the db shape
     *
     * @param {String} txt the label to show
     * @param {Number} [optionalIndex] index where to insert the entity
     */
    addEntity: function(txt, optionalIndex)
    {
        var label =new draw2d.shape.basic.Label({
            text:txt,
            stroke:0,
            radius:0,
            bgColor:null,
            padding:5,
            fontColor:"#4a4a4a",
            resizeable:true
        });
        var _table=this;
        this.add(label);

        return label;
    },

    /**
     * @method
     * Remove the entity with the given index from the DB table shape.<br>
     * This method removes the entity without care of existing connections. Use
     * a draw2d.command.CommandDelete command if you want to delete the connections to this entity too
     *
     * @param {Number} index the index of the entity to remove
     */
    removeEntity: function(index)
    {
        this.remove(this.children.get(index+1).figure);
    },

    /**
     * @method
     * Returns the entity figure with the given index
     *
     * @param {Number} index the index of the entity to return
     */
    getEntity: function(index)
    {
        return this.children.get(index+1).figure;
    },
    setNodes:function(memento){
        var newId = memento.id;

        var output = this.classLabel.getOutputPort("output_"+this.createid);
        output.setName("output_"+newId);
        //var input = this.classLabel.getInputPort("input_"+this.createid);
        //input.setName("input_"+newId);
    },

    /**
     * @method
     * Set the name of the DB table. Visually it is the header of the shape
     *
     * @param name
     */
    setName: function(name)
    {
        this.classLabel.setText(name);

        return this;
    },


    /**
     * @method
     * Return an objects with all important attributes for XML or JSON serialization
     *
     * @returns {Object}
     */
    setXandY:function(memento){

        this.setPosition(memento.x,memento.y);
    },
    getPersistentAttributes : function()
    {
        var memento= this._super();

        memento.name = this.classLabel.getText();
        memento.entities   = [];
        this.children.each(function(i,e){

            if(i>0){ // skip the header of the figure
                memento.entities.push({
                    text:e.figure.getText(),
                    id: e.figure.id
                });
            }
        });

        return memento;
    },

    /**
     * @method
     * Read all attributes from the serialized properties and transfer them into the shape.
     *
     * @param {Object} memento
     * @return
     */
    setPersistentAttributes : function(memento)
    {
        if(!SurveyDraw.getStructurCheck('start')){
            this.setId(memento.id);
            //this._super(memento);
            this.setXandY(memento);
            this.setName(memento.name);

            this.setNodes(memento);
            if (memento.visible !== undefined) {this.setVisible(memento.visible);}
            if (memento.repaintBlocked !== undefined) {this.repaintBlocked = memento.repaintBlocked;}

            if(typeof memento.entities !== "undefined"){
                $.each(memento.entities, $.proxy(function(i,e){
                    var entity = this.addEntity(e.text);
                    entity.id = e.id;
                },this));
            }
            SurveyDraw.setStructurCheck('start',true);
            return this;
        }
    },

    openContextMenuLabel:function(_table,emitter, event){
        $.contextMenu({
            selector: 'body',
            events:
                {
                    hide:function(){ $.contextMenu( 'destroy' ); }
                },
            callback: $.proxy(function(key, options)
            {
                switch(key){
                    case "set_routing":
                        Survey.ContextMenuSetRouting(_table,emitter, event);
                        break;
                    default:
                        break;
                }

            },this),
            x:event.x,
            y:event.y,
            items:
                {
                    //"change_color":{name:"@lg_change_layout@"}
                    "set_routing":{name:"@lg_survey_set_routing@"}
                    // "move_question":{name:"@lg_survey_move_question@"}
                }
        });
    }
});

//normal survey Struct
//Survey.SurveyStruct.js

Survey.SurveyStruct = draw2d.shape.layout.VerticalLayout.extend({

    NAME: "Survey.SurveyStruct",
    createid:'',

    init : function(attr)

    {
        var me = this;
        this._super($.extend({bgColor:"#3b679e", color:"#ffffff",cssClass:'white-border',stroke:1, radius:3},attr));

        this.classLabel = new draw2d.shape.basic.Label({
            text:"ClassName",
            stroke:0,
            bold:true,
            fontColor:"#ffffff",
            bgColor:"#3b679e",
            radius: this.getRadius(),
            padding:15,
            resizeable:true
        });
        //this.classLabel.installEditor(new draw2d.ui.LabelEditor());
        var _table=this;
        this.setVisible(false);
        this.repaintBlocked = false;
        this.tooltip = null;
        this.setDeleteable( false );
        this.classLabel.on("contextmenu", function(emitter, event){
            _table.openContextMenuLabel(_table,emitter, event);
        });

        // check for is Question or not later!
        this.isQuestion = true;

        this.classLabel.on("dblclick", function(emitter, event){
            Ext.Msg.show({
                title: 'Frage',
                msg: _table.setOldText,
                buttons: Ext.Msg.OK,
                icon: Ext.MessageBox.INFO
            });
        });
        var input = this.classLabel.createPort("input");
        input.setName("input_"+this.id);
        input.onConnect = function(connection){
            var thisInputName =	this.parent.parent.y;
            var conOutputName = connection.sourcePort;
            //if(conOutputName.parent.parent.y >= thisInputName){
            //connection.setTarget(connection.oldTarget);
            //alert('@lg_no_connection_on_same_label@');
            //}

        };

        this.createid = this.id;
        var  ddPolicy = new draw2d.policy.figure.DragDropEditPolicy();
        input.installEditPolicy(ddPolicy);
        var output = this.classLabel.createPort("output");
        output.setName("output_"+this.id);
        // Output Port einer Frage - Contextmenue
        output.on("contextmenu", function(emitter, event){
            // console.log(emitter);
            Survey.ContextMenuRouting(_table,emitter, event);
            //_table.openContextMenu(_table,emitter, event);
        });
        output.onConnect = function(connection){
            connection.setColor("#ff8000");

            //var thisOutputName =	this.parent.classLabel.inputPorts.data[0].name;
            //var conOutputName = connection.targetPort.name;
            if(this.connections.data[1] !== undefined){
                connection.setSource(connection.oldSource);
                alert('An diesen Knoten ist bereits eine Verbindung angeschlossen');
            }
            /*if(conOutputName === thisOutputName){
             connection.setSource(connection.oldSource);
             alert('Die Quelle darf nicht beim selben Ziel angeschlossen werden');
             }*/
            me.getConnectedPort();
        };
        output.onDisconnect = function(connection){
            connection.oldSource = connection.getSource();
            connection.oldTarget = connection.getTarget();
        };
        //this.installEditPolicy(new draw2d.policy.figure.HorizontalEditPolicy());
        //this.toFront();
        var _table = this;
        /*this.on("contextmenu", function(emitter, event){
         _table.openContextMenuRouting(_table,emitter, event);
         });  */

        this.add(this.classLabel);

    },


    onDrag:function(x, y,x2,y2){
        /*console.log(x+this.x);
         console.log(y+this.y);
         console.log('Absolut');*/
        //console.log(this.getAbsoluteX());

        //SurveyDraw.view.initialWidth = 800;
        //

        /*console.log('this + window');
         console.log(this);
         console.log($(window));
         console.log($(window).innerHeight()-132);
         console.log($(window).width());
         console.log('jo2');
         console.log(x2);
         console.log(y2);
         console.log('ScrollArea');*/
        /*SurveyDraw.view.resizeHandles.setPersistentAttributes(
         {height:'1000'});
         //this.canvas.clear();
         //this.canvas.setDimension(dim);
         //console.log(this.canvas.getScrollArea().scrollTop());
         //console.log(this.canvas.getScrollArea());

         //console.log(this.canvas.getScrollArea().scrollLeft());*/
        var theHeight = $(window).innerHeight()-132-200	+this.canvas.getScrollArea().scrollTop() ;
        if(($(window).innerHeight()-132+this.canvas.getScrollArea().scrollTop()) <= (this.getAbsoluteY() + this.height)){
            this.canvas.getScrollArea().scrollTop(theHeight);
        }
        if(this.canvas.getScrollArea().scrollTop()  > 0){
            if((this.canvas.getScrollArea().scrollTop()) > this.getAbsoluteY()){
                this.canvas.getScrollArea().scrollTop(0);

            }
        }
        this._super(x, y,x2,y2);
    },
    /**
     * @method
     * Add an entity to the db shape
     *
     * @param {String} txt the label to show
     * @param {Number} [optionalIndex] index where to insert the entity
     */
    addEntity: function(txt, optionalIndex)
    {
        var label =new draw2d.shape.basic.Label({
            text:txt.text,
            stroke:0,
            radius:0,
            bgColor:txt.bgColor,
            padding:5,
            fontColor:"#4a4a4a",
            resizeable:true
        });
        var _table=this;
        // Antworten einer Umfrage - Contextmenue
        label.on("contextmenu", function(emitter, event){
            Survey.ContextMenuRouting(_table,emitter, event);
            //_table.openContextMenu(_table,emitter, event);
        });


        // var input = label.createPort("input");
        var output= label.createPort("output");

        // Output Port einer Antwort - Contextmenue
        output.on("contextmenu", function(emitter, event){
            Survey.ContextMenuRouting(_table,emitter, event);
            //_table.openContextMenu(_table,emitter, event);
        });

        //input.setName("input_"+label.id);
        output.setName("output_"+label.id);

        var setOldText = null;

        if($.isNumeric(optionalIndex)){
            this.add(label, null, optionalIndex+1);
        }
        else{
            this.add(label);
        }

        return label;
    },

    /**
     * @method
     * Remove the entity with the given index from the DB table shape.<br>
     * This method removes the entity without care of existing connections. Use
     * a draw2d.command.CommandDelete command if you want to delete the connections to this entity too
     *
     * @param {Number} index the index of the entity to remove
     */
    removeEntity: function(index)
    {
        this.remove(this.children.get(index+1).figure);
    },
    onDrop : function(droppedDomNode, x, y, shiftKey, ctrlKey)
    {

        if(droppedDomNode instanceof Survey.Connection){
            var newTarget = droppedDomNode.getTarget();
            //droppedDomNode.sourcePort = droppedDomNode.getSource();

            droppedDomNode.setTarget(this.children.data[0].figure.inputPorts.data[0]);
            //var oldSource = droppedDomNode.getSource();
            //droppedDomNode.setSource(this.getOutputPort(0));

            var connector=  new Survey.Connection({
            });
            connector.setSource(this.children.data[0].figure.outputPorts.data[0]);
            connector.setTarget(newTarget);
            this.getCanvas().add(connector);
            //var additionalConnection = draw2d.Connection.createConnection(this.children.data[0].figure.outputPorts.data[0],newTarget);
            //this.getCanvas().add(additionalConnection);
            //additionalConnection.setSource(oldSource);
            //additionalConnection.setTarget(this.getInputPort(0));

        }
        this._super(droppedDomNode, x, y, shiftKey, ctrlKey);
        // create a command for the undo/redo support
        var command = new draw2d.command.CommandAdd(this, figure, x, y);
        this.getCommandStack().execute(command);
    },
    openContextMenuLabel:function(_table,emitter, event){
        $.contextMenu({
            selector: 'body',
            events:
                {
                    hide:function(){ $.contextMenu( 'destroy' ); }
                },
            callback: $.proxy(function(key, options)
            {
                switch(key){
                    case "change_color":
                        var win = Ext.widget('colorPickerWindow');
                        win.surveyEmitter = emitter;
                        win.down('colorCombo[name=color]').setValue(emitter.fontColor.hashString);
                        win.down('colorCombo[name=bgcolor]').setValue(emitter.bgColor.hashString);
                        break;
                    case "move_question":
                        var panel = Bi.app.getController('Bi.controller.MainController').getMainPanel().down('#survey_card').down('#surveyquestion');
                        var record = panel.record;

                        var menu = Ext.widget('survey_menu_move_question');
                        menu.showAt(event.x, event.y, true);
                        menu.surveyEmitter = emitter;
                        menu.questionid = emitter.parent.id;
                        menu.surveyid = record.get('_id');
                        menu.record = record;
                        var store = Ext.getStore('survey_next_questions_store');
                        store.getProxy().setExtraParams({
                            surveyid: record.get('_id'),
                            current_question_id: emitter.parent.id,
                            catalogue: record.get('catalogue'),
                            move: true
                        });
                        store.load();
                        break;
                    case "set_routing":
                        Survey.ContextMenuSetRouting(_table,emitter, event);
                        break;
                    default:
                        break;
                }

            },this),
            x:event.x,
            y:event.y,
            items:
                {
                    //"change_color":{name:"@lg_change_layout@"}
                    "set_routing":{name:"@lg_survey_set_routing@"}
                    // "move_question":{name:"@lg_survey_move_question@"}
                }
        });
    },

    /**
     * @method
     * Returns the entity figure with the given index
     *
     * @param {Number} index the index of the entity to return
     */
    getEntity: function(index)
    {
        return this.children.get(index+1).figure;
    },
    setNodes:function(memento){
        var newId = memento.id;

        var input = this.classLabel.getInputPort("input_"+this.createid);
        input.setName("input_"+newId);

        var output = this.classLabel.getOutputPort("output_"+this.createid);
        output.setName("output_"+newId);
    },

    /**
     * @method
     * Set the name of the DB table. Visually it is the header of the shape
     *
     * @param name
     */
    setName: function(name)
    {
        this.classLabel.setText(name);

        return this;
    },

    /**
     * @method
     * Return an objects with all important attributes for XML or JSON serialization
     *
     * @returns {Object}
     */
    setXandY:function(memento){

        this.setPosition(memento.x,memento.y);
    },
    getConnectedPort:function(){
        var me = this;
        var count = 0;
        var items = this.children.getSize();
        if(this.children.getSize() > 1){
            this.children.each(function(i,e){
                if(e.figure.getOutputPort(0).connections.data[0] !== undefined){
                    count = count+1;
                }
                if(items===count){
                    var connection =me.children.data[0].figure.outputPorts.data[0].connections.data[0];
                    //var cmd =  new draw2d.CommandDelete(connection);
                    //me.canvas.getCommandStack().excute(cmd);
                    me.canvas.removeFigure(connection);
                }


            });
        }
    },
    getPersistentAttributes : function()
    {
        var memento= this._super();

        memento.name = this.classLabel.getText();
        memento.entities   = [];
        this.children.each(function(i,e){

            if(i>0){ // skip the header of the figure
                memento.entities.push({
                    text:e.figure.getText(),
                    bgColor: '#DBDDDE',
                    id: e.figure.id
                });
            }
        });

        return memento;
    },

    /**
     * @method
     * Read all attributes from the serialized properties and transfer them into the shape.
     *
     * @param {Object} memento
     * @return
     */
    setPersistentAttributes : function(memento)
    {
        this.setXandY(memento);
        this.setOldText=memento.name;
        memento.name= Ext.String.ellipsis(memento.name,70);
        this.setName(memento.name);
        this.setId(memento.id);
        this.setNodes(memento);
        this.classLabel.setBackgroundColor(memento.bgColor);
        this.classLabel.setFontColor(memento.color);
        if (memento.visible !== undefined) {this.setVisible(memento.visible);}
        if (memento.repaintBlocked !== undefined) {this.repaintBlocked = memento.repaintBlocked;}

        var me = this;
        if(typeof memento.entities !== "undefined"){
            $.each(memento.entities, $.proxy(function(i,e){
                var entity = this.addEntity(e);
                entity.id = e.id;
                if(memento.id !== "start"&& memento.id !== 'end'){
                    entity.getOutputPort(0).setName("output_"+e.id);
                    entity.bgColor.hashString = '#DBDDDE';
                    //console.log(entity);
                    entity.getOutputPort(0).onConnect = function(connection){
                        connection.setColor("#4caf50");

                        if(this.connections.data[1] !== undefined){

                            connection.setSource(connection.oldSource);
                            alert('@lg_already_have_connection@');
                        }
                        me.getConnectedPort();
                    };
                    entity.getOutputPort(0).onDisconnect = function(connection){
                        connection.oldSource = connection.getSource();
                        connection.oldTarget = connection.getTarget();
                    };

                }else{
                    entity.removePort(entity.getOutputPort(0));
                }
            },this));
        }
        return this;
    }

});

Survey.ContextMenuSetRouting = function (_table,emitter, event){
    var questionID;

    // beim Outport Port die ID von 2x parent holen
    if (emitter.NAME == "draw2d.OutputPort") {
        questionID = emitter.parent.parent.id;
    } else {
        questionID = emitter.parent.id
    }

    Bi.app.fireEvent('drawcontextmenusetrouting', emitter, questionID);
};

//End of a Survey
//Survey.EndStruct.js

Survey.EndStruct = draw2d.shape.layout.VerticalLayout.extend({

    NAME: "Survey.EndStruct",
    createid:'',
    init : function(attr)
    {

        if(!SurveyDraw.getStructurCheck('end')){
            this._super($.extend({bgColor:"#3b679e", color:"#ffffff",cssClass:'white-border',stroke:1, radius:3},attr));

            this.classLabel = new draw2d.shape.basic.Label({
                text:"ClassName",
                stroke:0,
                bold:true,
                fontColor:"#ffffff",
                bgColor:"#3b679e",
                radius: this.getRadius(),
                padding:15,
                resizeable:true
            });
            this.setVisible(false);
            this.repaintBlocked = false;

            this.setDeleteable( false );
            var input = this.classLabel.createPort("input");
            input.setName("input_"+this.id);

            input.onConnect = function(connection){
                var thisInputName =	this.parent.parent.y;
                var conOutputName = connection.sourcePort;
            };

            this.createid = this.id;
            var  ddPolicy = new draw2d.policy.figure.DragDropEditPolicy();
            input.installEditPolicy(ddPolicy);
            var _table = this;
            this.add(this.classLabel);

        }else{
            this._super();
            this.removeItem= true;
        }

    },

    /**
     * @method
     * Add an entity to the db shape
     *
     * @param {String} txt the label to show
     * @param {Number} [optionalIndex] index where to insert the entity
     */
    addEntity: function(txt, optionalIndex)
    {
        var label =new draw2d.shape.basic.Label({
            text:txt,
            stroke:0,
            radius:0,
            bgColor:null,
            padding:5,
            fontColor:"#4a4a4a",
            resizeable:true
        });
        var _table=this;
        this.add(label);

        return label;
    },

    /**
     * @method
     * Remove the entity with the given index from the DB table shape.<br>
     * This method removes the entity without care of existing connections. Use
     * a draw2d.command.CommandDelete command if you want to delete the connections to this entity too
     *
     * @param {Number} index the index of the entity to remove
     */
    removeEntity: function(index)
    {
        this.remove(this.children.get(index+1).figure);
    },

    /**
     * @method
     * Returns the entity figure with the given index
     *
     * @param {Number} index the index of the entity to return
     */
    getEntity: function(index)
    {
        return this.children.get(index+1).figure;
    },
    setNodes:function(memento){
        var newId = memento.id;

        var input = this.classLabel.getInputPort("input_"+this.createid);
        input.setName("input_"+newId);

        //var output = this.classLabel.getOutputPort("output_"+this.createid);
        //  output.setName("output_"+newId);
    },

    /**
     * @method
     * Set the name of the DB table. Visually it is the header of the shape
     *
     * @param name
     */
    setName: function(name)
    {
        this.classLabel.setText(name);

        return this;
    },


    /**
     * @method
     * Return an objects with all important attributes for XML or JSON serialization
     *
     * @returns {Object}
     */
    setXandY:function(memento){

        this.setPosition(memento.x,memento.y);

        SurveyDraw.view.biX = $(window).width()-50;
        SurveyDraw.view.biY = memento.y+200;
    },
    getPersistentAttributes : function()
    {
        var memento= this._super();

        memento.name = this.classLabel.getText();
        memento.entities   = [];
        this.children.each(function(i,e){

            if(i>0){ // skip the header of the figure
                memento.entities.push({
                    text:e.figure.getText(),
                    id: e.figure.id
                });
            }
        });

        return memento;
    },

    /**
     * @method
     * Read all attributes from the serialized properties and transfer them into the shape.
     *
     * @param {Object} memento
     * @return
     */
    setPersistentAttributes : function(memento)
    {
        if(!SurveyDraw.getStructurCheck('end')){
            this.setXandY(memento);
            this.setName(memento.name);
            this.setId(memento.id);
            this.setNodes(memento);
            if (memento.visible !== undefined) {this.setVisible(memento.visible);}
            if (memento.repaintBlocked !== undefined) {this.repaintBlocked = memento.repaintBlocked;}

            if(typeof memento.entities !== "undefined"){
                // console.log(memento.entities);
                $.each(memento.entities, $.proxy(function(i,e){
                    var entity = this.addEntity(e.text);
                    entity.id = e.id;
                    entity.getInputPort(0).setName("input_"+e.id);
                    entity.getOutputPort(0).setName("output_"+e.id);
                },this));
            }
            SurveyDraw.setStructurCheck('end',true);
            return this;
        }
    }

});

// creator for the connections from source to the target port
draw2d.Configuration.factory.createConnection=function(sourcePort, targetPort) {
    // return my special kind of connection
    if(sourcePort.connections.data[0] === undefined) {
        var connector = new Survey.Connection();
        return connector;
    } else{
        Ext.Msg.alert('@lg_error@', '@lg_already_have_connection@');
    }
};

Survey.repaintQuestionsOrder = function(jsonResponse) {
    SurveyDraw.view.clear();
    SurveyDraw.clearStructurCheck();
    var reader = new draw2d.io.json.Reader();
    Res = reader.unmarshal(SurveyDraw.view, jsonResponse);
    Res.each(function(i,value){value.setVisible(true);});
    Res.each(function(i,value){value.repaintBlocked = false;value.repaint();});
};


// contains the Survey Draw Application when initialized
var SurveyDraw = null;
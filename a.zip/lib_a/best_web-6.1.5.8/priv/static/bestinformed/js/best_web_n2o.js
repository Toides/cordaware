
// N2O CORE

var active      = false,
    debug       = false,
    protocol    = window.location.protocol == 'https:' ? "wss://" : "ws://",
    //querystring = window.location.pathname + window.location.search,
    host        = null == transition.host ? window.location.hostname : transition.host,
    port        = null == transition.port ? window.location.port : transition.port,
    protos      = [ $client, $bert ];

function N2O_start() {
    ws = new bullet(protocol + host + (port==""?"":":"+port) + ws(window.location.pathname,window.location.search));
    ws.onmessage = function (evt) { // formatters loop
    for (var i=0;i<protos.length;i++) { p = protos[i]; if (p.on(evt, p.do).status == "ok") return; } };
    ws.onopen = function() { if (!active) { console.log('Connect'); ws.send('N2O,'+transition.pid); active=true; } };
    ws.onclose = function() { active = false; console.log('Disconnect'); }; next(); }


function ws(p,s) {
    var arr = p.split("/"),
        i   = arr.length === 1 ? 1 : (arr[1] === "" || arr[1] === "bi_web") ? 1 : 2;
    arr.splice(i, 0, "ws");
    return arr.join("/") + s}
function qi(name) { return document.getElementById(name); }
function qs(name) { return document.querySelector(name);  }
function qn(name) { return document.createElement(name);  }
function is(x,num,name) { return x.t==106?false:(x.v.length === num && x.v[0].v === name); }

/// N2O Protocols
var $io = {}; $io.on = function onio(r, cb) { if (is(r,3,'io')) {
    try { eval(r.v[1].v); if (typeof cb == 'function') cb(r); return { status: "ok" }; }
    catch (e) { console.log(e); return { status: '' }; } } else return { status: '' }; }

var $file = {}; $file.on = function onfile(r, cb) { if (is(r,12,'ftp')) {
    if (typeof cb == 'function') cb(r); return { status: "ok" }; } else return { status: ''}; }

var $bin = {}; $bin.on = function onbin(r, cb) { if (is(r,2,'bin')) {
    if (typeof cb == 'function') cb(r); return { status: "ok" }; } else return { status: '' }; }

// BERT Formatter

var $bert = {}; $bert.protos = [$io,$bin,$file]; $bert.on = function onbert(evt, cb) {
    if (Blob.prototype.isPrototypeOf(evt.data) && (evt.data.length > 0 || evt.data.size > 0)) {
        var r = new FileReader();
        r.addEventListener("loadend", function() {
            try { erlang = dec(r.result);
                  if (debug) console.log(JSON.stringify(erlang));
                  if (typeof cb  == 'function') cb(erlang);
                  for (var i=0;i<$bert.protos.length;i++) {
                    p = $bert.protos[i]; if (p.on(erlang, p.do).status == "ok") return; }
            } catch (e) { console.log(e); } });
        r.readAsArrayBuffer(evt.data);
        return { status: "ok" }; } else return { status: "error", desc: "data" }; }


    function loadScript(src,id) {

        if (!document.getElementById(id)) {
            var script = document.createElement('script');
            script.type = 'text/javascript';
            script.src = src;
            script.id = id;
            document.getElementsByTagName('head')[0].appendChild(script);
            console.log('Script with id:' + id + ' loaded!');
        }
    }

    function loadScriptSync(src,id)
    {
        if (!document.getElementById(id)) {
            var req = new XMLHttpRequest();
            req.open("GET", src, false); // 'false': synchronous.
            req.send(null);

            var headElement = document.getElementsByTagName("head")[0];
            var script = document.createElement("script");
            script.type = "text/javascript";
            script.text = req.responseText;
            script.id = id;
            headElement.appendChild(script);
        }
    }

    function SSO() {
        var i = document.createElement('iframe');
        i.style.display = 'none';
        i.onload = function() { i.parentNode.removeChild(i); };
        i.src = 'best_web_sso_auth';
        document.body.appendChild(i);
        }


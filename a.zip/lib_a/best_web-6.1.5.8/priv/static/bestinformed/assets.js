/**
 * Created by max.neuhauser on 03.04.2017.
 */
Ext.define('Bi.model.assets.Dicv', {
    extend: Ext.data.Model,
    alias: 'model.assetsDicv',
    idProperty: '_id',
    fields: [
        {
            name: '_id'
        },
        {
            type: 'string',
            name: 'name'
        },
        {
            type: 'string',
            name: 'value'
        },
        {
            type: 'string',
            name: 'result'
        }
    ]
});

/**
 * Created by max.neuhauser on 11.04.2017.
 */
Ext.define('Bi.model.assets.ColumnChart', {
    extend: Ext.data.Model,
    alias: 'model.assetsColumnChart',
    idProperty: '_id',
    fields: [
        {
            name: '_id'
        },
        {
            type: 'string',
            name: 'username'
        },
        {
            type: 'string',
            name: 'dicv'
        },
        {
            type: 'integer',
            name: 'value'
        }
    ]
});

/**
 * Created by max.neuhauser on 12.04.2017.
 */
Ext.define('Bi.model.assets.Grid', {
    extend: Ext.data.Model,
    alias: 'model.assetsGrid',
    idProperty: '_id',
    fields: [
        {
            name: '_id'
        },
        {
            name: 'username',
            type: 'string'
        },
        {
            name: 'value',
            type: 'string'
        }
    ]
});

/**
 * Created by max.neuhauser on 11.05.2017.
 */
Ext.define('Bi.model.assets.Dicvoperator', {
    extend: Ext.data.Model,
    alias: 'model.assetsDicvoperator',
    idProperty: '_id',
    fields: [
        {
            name: '_id'
        },
        {
            type: 'string',
            name: 'text'
        },
        {
            type: 'string',
            name: 'value'
        }
    ]
});

/**
 * Created by max.neuhauser on 03.04.2017.
 */
Ext.define('Bi.store.assets.Dicvs', {
    extend: Ext.data.Store,
    alias: 'store.assetsDicvs',
    autoLoad: false,
    model: 'Bi.model.assets.Dicv',
    nodeParam: '_rev',
    proxy: {
        type: 'ajax',
        api: {
            read: 'bi_assets?bi_action=read&bi_tag=dicvs'
        },
        reader: {
            type: 'json',
            rootProperty: 'rows',
            totalProperty: 'total_rows'
        },
        idParam: '_id',
        url: '',
        actionMethods: {
            create: 'POST',
            read: 'GET',
            update: 'PUT',
            destroy: 'DELETE'
        }
    },
    sorters: {
        property: 'name'
    }
});

/**
 * Created by max.neuhauser on 11.04.2017.
 */
Ext.define('Bi.store.assets.ColumnCharts', {
    extend: Ext.data.Store,
    alias: 'store.assetsColumnCharts',
    model: 'Bi.model.assets.ColumnChart',
    autoLoad: false,
    pageSize: 0,
    proxy: {
        type: 'ajax',
        app: 'assets',
        api: {
            read: 'bi_assets?bi_action=display&bi_tag=columnchart'
        },
        reader: {
            type: 'json',
            rootProperty: 'rows',
            totalProperty: 'total_rows'
        }
    },
    sorters: {
        property: 'username'
    }
});

/**
 * Created by max.neuhauser on 12.04.2017.
 */
Ext.define('Bi.store.assets.Grids', {
    extend: Ext.data.Store,
    alias: 'store.assetsGrids',
    model: 'Bi.model.assets.Grid',
    autoLoad: false,
    pageSize: 0,
    proxy: {
        type: 'ajax',
        app: 'assets',
        api: {
            read: 'bi_assets?bi_action=display&bi_tag=grid'
        },
        reader: {
            type: 'json',
            rootProperty: 'rows',
            totalProperty: 'total_rows'
        }
    },
    sorters: {
        property: 'username'
    }
});

/**
 * Created by max.neuhauser on 11.05.2017.
 */
Ext.define('Bi.store.assets.Dicvoperators', {
    extend: Ext.data.Store,
    alias: 'store.assetsDicvoperators',
    data: [
        {
            value: 'diFileExists',
            text: 'diFileExists'
        },
        {
            value: 'diFileSize',
            text: 'diFileSize'
        },
        {
            value: 'diFileAge',
            text: 'diFileAge'
        },
        {
            value: 'diFileVersion',
            text: 'diFileVersion'
        },
        {
            value: 'diDirExists',
            text: 'diDirExists'
        },
        {
            value: 'diDiskSize',
            text: 'diDiskSize'
        },
        {
            value: 'diDiskFree',
            text: 'diDiskFree'
        },
        {
            value: 'diRegExists',
            text: 'diRegExists'
        },
        {
            value: 'diRegKey',
            text: 'diRegKey'
        },
        {
            value: 'diPrinterExists',
            text: 'diPrinterExists'
        },
        {
            value: 'diProcessRuns',
            text: 'diProcessRuns'
        },
        {
            value: 'diProcessRan',
            text: 'diProcessRan'
        },
        {
            value: 'diProcessList',
            text: 'diProcessList'
        },
        {
            value: 'diConnectedTo',
            text: 'diConnectedTo'
        },
        {
            value: 'diListen',
            text: 'diListen'
        },
        {
            value: 'diNetDirConnectedTo',
            text: 'diNetDirConnectedTo'
        },
        {
            value: 'diIniFileValue',
            text: 'diIniFileValue'
        },
        {
            value: 'diWMIValue',
            text: 'diWMIValue'
        },
        {
            value: 'diTitleExists',
            text: 'diTitleExists'
        },
        {
            value: 'diDefault',
            text: 'diDefault'
        }
    ]
});

Ext.define('Bi.view.assets.main.View', {
    extend: Ext.panel.Panel,
    alias: [
        'widget.assetsMainView',
        'widget.assets'
    ],
    viewModel: {
        type: 'assetsMainModel'
    },
    controller: 'assetsMainController',
    layout: 'card',
    reference: 'assets',
    defaults: {
        iconCls: 'fa fa-bar-chart'
    },
    items: [
        {
            xtype: 'assetsMainpanelView',
            reference: 'assetsMainpanel'
        },
        {
            xtype: 'assetsDicvView',
            reference: 'assetsDicv'
        }
    ]
});

/**
 * Created by max.neuhauser on 31.03.2017.
 */
Ext.define('Bi.view.assets.mainpanel.View', {
    extend: Ext.panel.Panel,
    alias: 'widget.assetsMainpanelView',
    viewModel: {
        type: 'assetsMainpanelModel'
    },
    title: '@lg_assets@',
    controller: 'assetsMainpanelController',
    reference: 'assetsMainpanel',
    layout: 'anchor',
    overflowY: 'scroll',
    overflowX: 'scroll',
    autoScroll: true,
    padding: 10,
    items: [
        {
            xtype: 'fieldset',
            padding: 10,
            minWidth: 600,
            bodyStyle: "background-color: transparent;",
            title: '@lg_assets_dicv_fieldset_title@',
            items: [
                {
                    xtype: 'container',
                    layout: 'hbox',
                    margin: '0 0 10 0',
                    items: [
                        {
                            xtype: 'combobox',
                            anchor: '40%',
                            reference: 'assetsDicvCombo',
                            fieldLabel: '@lg_assets_dicv@',
                            labelWidth: 200,
                            minWidth: 450,
                            width: '50%',
                            allowBlank: false,
                            allowOnlyWhitespace: false,
                            blankText: '@lg_blank_text@',
                            forceSelection: true,
                            queryMode: 'local',
                            store: 'assets.Dicvs',
                            typeAhead: false,
                            valueField: 'value',
                            displayField: 'name',
                            editable: false,
                            listeners: {
                                select: {
                                    fn: 'onDicvComboSelect',
                                    scope: 'controller'
                                },
                                expand: {
                                    fn: 'onDicvTagfieldExpand',
                                    scope: 'controller'
                                }
                            }
                        }
                    ]
                },
                {
                    xtype: 'container',
                    layout: 'hbox',
                    margin: '0 0 10 0',
                    items: [
                        {
                            xtype: 'combobox',
                            anchor: '40%',
                            reference: 'assetsDisplayCombo',
                            fieldLabel: '@lg_assets_display_combo@',
                            labelWidth: 200,
                            minWidth: 450,
                            width: '50%',
                            allowBlank: false,
                            allowOnlyWhitespace: false,
                            blankText: '@lg_blank_text@',
                            forceSelection: true,
                            queryMode: 'local',
                            store: {
                                fields: [
                                    'value',
                                    'text'
                                ],
                                data: [
                                    {
                                        value: 'chart',
                                        text: '@lg_assets_displaycombo_chart@'
                                    },
                                    {
                                        value: 'grid',
                                        text: '@lg_assets_displaycombo_grid@'
                                    }
                                ]
                            },
                            typeAhead: false,
                            valueField: 'value',
                            displayField: 'text',
                            editable: false,
                            listeners: {
                                select: {
                                    fn: 'onDisplayComboSelect',
                                    scope: 'controller'
                                }
                            }
                        }
                    ]
                },
                {
                    xtype: 'container',
                    layout: 'hbox',
                    margin: '0 0 10 0',
                    items: [
                        {
                            xtype: 'combobox',
                            anchor: '40%',
                            disabled: true,
                            reference: 'assetsChartRenderCombo',
                            fieldLabel: '@lg_assets_chart_render_combo@',
                            labelWidth: 200,
                            minWidth: 450,
                            width: '50%',
                            allowBlank: false,
                            allowOnlyWhitespace: false,
                            blankText: '@lg_blank_text@',
                            forceSelection: true,
                            queryMode: 'local',
                            store: {
                                fields: [
                                    'value',
                                    'text'
                                ],
                                data: [
                                    {
                                        value: 'without',
                                        text: '@lg_assets_chartrender_without@'
                                    },
                                    {
                                        value: 'byte',
                                        text: '@lg_assets_chartrender_byte@'
                                    },
                                    {
                                        value: 'kbyte',
                                        text: '@lg_assets_chartrender_kbyte@'
                                    },
                                    {
                                        value: 'mbyte',
                                        text: '@lg_assets_chartrender_mbyte@'
                                    },
                                    {
                                        value: 'gbyte',
                                        text: '@lg_assets_chartrender_gbyte@'
                                    }
                                ]
                            },
                            typeAhead: false,
                            valueField: 'value',
                            displayField: 'text',
                            editable: false,
                            listeners: {
                                select: {
                                    fn: 'onChartRenderComboSelect',
                                    scope: 'controller'
                                }
                            }
                        }
                    ]
                },
                {
                    xtype: 'container',
                    layout: 'hbox',
                    margin: '0 0 10 0',
                    items: [
                        {
                            xtype: 'button',
                            margin: '10 0 0 0',
                            text: '@lg_assets_display_button@',
                            reference: 'assetsSaveButton',
                            listeners: {
                                click: 'onButtonDisplayClick',
                                scope: 'controller'
                            }
                        },
                        {
                            xtype: 'button',
                            hidden: true,
                            margin: '10 0 0 10',
                            text: '@lg_assets_dicv_button@',
                            reference: 'assetsDicvButton',
                            listeners: {
                                click: 'onButtonDicvClick',
                                scope: 'controller'
                            }
                        }
                    ]
                }
            ]
        },
        /*{
                    xtype: 'form',
                    flex: 1,
                    items: [
                        {
                            xtype: 'combobox',
                            anchor: '40%',
                            reference: 'assetsDicvCombo',
                            fieldLabel: '@lg_assets_dicv@',
                            labelWidth: 250,
                            allowBlank: false,
                            allowOnlyWhitespace: false,
                            blankText: '@lg_blank_text@',
                            forceSelection: true,
                            queryMode: 'local',
                            store: 'assets.Dicvs',
                            typeAhead: false,
                            valueField: 'value',
                            displayField: 'name',
                            editable: false,
                            listeners: {
                                select: {
                                    fn: 'onDicvComboSelect',
                                    scope: 'controller'
                                },
                                expand: {
                                    fn: 'onDicvTagfieldExpand',
                                    scope: 'controller'
                                }
                            }
                        },
                        {
                            xtype: 'combobox',
                            anchor: '40%',
                            reference: 'assetsDisplayCombo',
                            fieldLabel: '@lg_assets_display_combo@',
                            labelWidth: 250,
                            allowBlank: false,
                            allowOnlyWhitespace: false,
                            blankText: '@lg_blank_text@',
                            forceSelection: true,
                            queryMode: 'local',
                            store: {
                                fields: ['value', 'text'],
                                data: [
                                    {
                                        value: 'chart',
                                        text: '@lg_assets_displaycombo_chart@'
                                    },
                                    {
                                        value: 'grid',
                                        text: '@lg_assets_displaycombo_grid@'
                                    }
                                ]
                            },
                            typeAhead: false,
                            valueField: 'value',
                            displayField: 'text',
                            editable: false,
                            listeners: {
                                select: {
                                    fn: 'onDisplayComboSelect',
                                    scope: 'controller'
                                }
                            }
                        },
                        {
                            xtype: 'combobox',
                            anchor: '40%',
                            disabled: true,
                            reference: 'assetsChartRenderCombo',
                            fieldLabel: '@lg_assets_chart_render_combo@',
                            labelWidth: 250,
                            allowBlank: false,
                            allowOnlyWhitespace: false,
                            blankText: '@lg_blank_text@',
                            forceSelection: true,
                            queryMode: 'local',
                            store: {
                                fields: ['value', 'text'],
                                data: [
                                    {
                                        value: 'without',
                                        text: '@lg_assets_chartrender_without@'
                                    },
                                    {
                                        value: 'byte',
                                        text: '@lg_assets_chartrender_byte@'
                                    },
                                    {
                                        value: 'kbyte',
                                        text: '@lg_assets_chartrender_kbyte@'
                                    },
                                    {
                                        value: 'mbyte',
                                        text: '@lg_assets_chartrender_mbyte@'
                                    },
                                    {
                                        value: 'gbyte',
                                        text: '@lg_assets_chartrender_gbyte@'
                                    }
                                ]
                            },
                            typeAhead: false,
                            valueField: 'value',
                            displayField: 'text',
                            editable: false,
                            listeners: {
                                select: {
                                    fn: 'onChartRenderComboSelect',
                                    scope: 'controller'
                                }
                            }
                        }
                    ],
                    dockedItems: [
                        {
                            xtype: 'bitoolbar',
                            dock: 'bottom',
                            ui: 'footer',
                            items: [
                                {
                                    xtype: 'button',
                                    text: '@lg_assets_display_button@',
                                    reference: 'assetsSaveButton',
                                    listeners: {
                                        click: 'onButtonDisplayClick',
                                        scope: 'controller'
                                    }
                                }
                            ]
                        }
                    ]
                }*/
        {
            xtype: 'fieldset',
            padding: 10,
            title: '@lg_assets_charts_fieldset_title@',
            items: [
                {
                    xtype: 'displayfield',
                    reference: 'assetsDisplayError',
                    hidden: true,
                    value: '<font color="red"><b>@lg_assets_display_error_show@</b></font>'
                },
                {
                    xtype: 'panel',
                    reference: 'assetsDisplayPanel',
                    hidden: true,
                    padding: 10,
                    items: [
                        {
                            xtype: 'cartesian',
                            reference: 'assetsColumnChart',
                            theme: {
                                type: 'muted'
                            },
                            autoScroll: false,
                            store: 'assets.ColumnCharts',
                            width: '100%',
                            height: 600,
                            insetPadding: 50,
                            animation: Ext.isIE8 ? false : {
                                easing: 'backOut',
                                duration: 500
                            },
                            axes: [
                                {
                                    type: 'numeric3d',
                                    position: 'left',
                                    fields: 'value',
                                    majorTickSteps: 10,
                                    minimum: 0,
                                    label: {
                                        textAlign: 'right'
                                    },
                                    renderer: 'onAxisLabelRender',
                                    title: '@lg_assets_columnchart_axes@',
                                    grid: {
                                        odd: {
                                            fillStyle: 'rgba(255, 255, 255, 0.06)'
                                        },
                                        even: {
                                            fillStyle: 'rgba(0, 0, 0, 0.03)'
                                        }
                                    }
                                },
                                {
                                    type: 'category3d',
                                    position: 'bottom',
                                    fields: 'username',
                                    label: {
                                        rotate: {
                                            degrees: -45
                                        }
                                    },
                                    grid: true
                                }
                            ],
                            series: [
                                {
                                    type: 'bar3d',
                                    xField: 'username',
                                    yField: 'value',
                                    style: {
                                        minGapWidth: 20
                                    },
                                    highlightCfg: {
                                        saturationFactor: 1.5
                                    },
                                    label: {
                                        field: 'value',
                                        display: 'insideEnd',
                                        renderer: 'onSeriesLabelRender'
                                    }
                                }
                            ]
                        }
                    ]
                },
                {
                    xtype: 'panel',
                    reference: 'assetsGridPanel',
                    hidden: true,
                    padding: 10,
                    items: [
                        {
                            xtype: 'grid',
                            reference: 'assetsGridGrid',
                            columnLines: true,
                            forceFit: true,
                            width: '100%',
                            height: 200,
                            store: 'assets.Grids',
                            viewConfig: {
                                emptyText: '@lg_no_data_found@'
                            },
                            scrollable: false,
                            columns: [
                                {
                                    xtype: 'gridcolumn',
                                    renderer: function(value, metaData, record, rowIndex, colIndex, store, view) {
                                        return Bi.app.renderer_tooltip(value, metaData, record, rowIndex, colIndex, store, view);
                                    },
                                    dataIndex: 'username',
                                    text: '@lg_name@'
                                },
                                {
                                    xtype: 'gridcolumn',
                                    dataIndex: 'value',
                                    text: '@lg_assets_value@'
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    ]
});

/**
 * Created by max.neuhauser on 11.05.2017.
 */
Ext.define('Bi.view.assets.dicv.View', {
    extend: Ext.panel.Panel,
    alias: 'widget.assetsDicvView',
    viewModel: {
        type: 'assetsDicvModel'
    },
    title: '@lg_assets@',
    controller: 'assetsDicvController',
    reference: 'assetsDicv',
    layout: 'anchor',
    overflowY: 'scroll',
    overflowX: 'scroll',
    autoScroll: true,
    padding: 10,
    items: [
        {
            xtype: 'fieldset',
            padding: 10,
            minWidth: 600,
            bodyStyle: "background-color: transparent;",
            title: '@lg_assets_dicv_title@',
            items: [
                {
                    xtype: 'container',
                    layout: 'hbox',
                    margin: '0 0 10 0',
                    items: [
                        {
                            xtype: 'textfield',
                            name: 'dicv_name',
                            reference: 'assetsDicvName',
                            anchor: '100%',
                            minWidth: 200,
                            width: '50%',
                            labelWidth: 150,
                            fieldLabel: '@lg_assets_dicv_name@'
                        }
                    ]
                },
                {
                    xtype: 'container',
                    layout: 'hbox',
                    margin: '0 0 10 0',
                    items: [
                        {
                            xtype: 'combobox',
                            anchor: '40%',
                            name: 'dicv_operator',
                            reference: 'assetsDicvOperatorCombo',
                            fieldLabel: '@lg_assets_dicv_operator@',
                            labelWidth: 150,
                            minWidth: 450,
                            width: '50%',
                            allowBlank: false,
                            allowOnlyWhitespace: false,
                            blankText: '@lg_blank_text@',
                            forceSelection: true,
                            queryMode: 'local',
                            store: 'assets.Dicvoperators',
                            typeAhead: false,
                            valueField: 'value',
                            displayField: 'text',
                            editable: false,
                            listeners: {
                                select: {
                                    fn: 'onDicvComboSelect',
                                    scope: 'controller'
                                },
                                expand: {
                                    fn: 'onDicvTagfieldExpand',
                                    scope: 'controller'
                                }
                            }
                        }
                    ]
                },
                {
                    xtype: 'container',
                    layout: 'hbox',
                    margin: '0 0 10 0',
                    items: [
                        {
                            xtype: 'textfield',
                            anchor: '100%',
                            name: 'dicv_value',
                            reference: 'assetsDicvValue',
                            minWidth: 200,
                            labelWidth: 150,
                            width: '50%',
                            fieldLabel: '@lg_assets_dicv_value@',
                            emptyText: '@lg_assets_dicv_value_empty@'
                        }
                    ]
                },
                {
                    xtype: 'container',
                    layout: 'hbox',
                    margin: '0 0 10 0',
                    items: [
                        {
                            xtype: 'button',
                            margin: '10 0 0 0',
                            text: '@lg_assets_dicv_send_button@',
                            reference: 'assetsSendButton',
                            listeners: {
                                click: 'onButtonSendClick',
                                scope: 'controller'
                            }
                        },
                        {
                            xtype: 'button',
                            margin: '10 0 0 10',
                            text: '@lg_assets_back_to_asset_button@',
                            reference: 'assetsAssetsBackButton',
                            listeners: {
                                click: 'onButtonAssetsBackClick',
                                scope: 'controller'
                            }
                        }
                    ]
                }
            ]
        }
    ]
});

Ext.define('Bi.controller.assets.Controller', {
    extend: Ext.app.Controller,
    alias: 'controller.assetsController',
    alternateClassName: [
        'Bi.controller.AssetsController'
    ],
    models: [
        'assets.Dicv',
        'assets.ColumnChart',
        'assets.Grid',
        'assets.Dicvoperator'
    ],
    stores: [
        'assets.Dicvs',
        'assets.ColumnCharts',
        'assets.Grids',
        'assets.Dicvoperators'
    ],
    views: [
        'assets.main.View',
        'assets.mainpanel.View',
        'assets.dicv.View'
    ],
    initscript: function() {
        Bi.app.fireEvent('initscript', 'Assets');
    },
    onNotify: function(action, eOpts) {
        if (action === 'store') {
            var type = eOpts.type;
            var json = eOpts.doc;
            switch (type) {
                case 'bi-assets':
                    break;
            }
        }
    },
    init: function(application) {
        application.on({
            notify: {
                fn: this.onNotify,
                scope: this
            }
        });
    }
});

/**
 * Created by max.neuhauser on 11.05.2017.
 */
Ext.define('Bi.view.assets.dicv.Controller', {
    extend: Ext.app.ViewController,
    alias: 'controller.assetsDicvController',
    onDicvComboSelect: function() {},
    onDicvTagfieldExpand: function(field, eOpts) {
        var store = field.getStore();
        store.needloaded = true;
        Bi.app.expandTagfield(field, eOpts);
    },
    onButtonSendClick: function(button, e, eOpts) {
        var card = Bi.app.getComp('assetsMainView');
        var dicvform = card.lookupReference('assetsDicv');
        var dicvname = dicvform.lookupReference('assetsDicvName');
        var dicvoperator = dicvform.lookupReference('assetsDicvOperatorCombo');
        var dicvvalue = dicvform.lookupReference('assetsDicvValue');
        Ext.Ajax.request({
            url: 'bi_assets?bi_action=send&bi_tag=dicv',
            method: 'GET',
            params: {
                dicvname: dicvname.getValue(),
                dicvoperator: dicvoperator.getValue(),
                dicvvalue: dicvvalue.getValue()
            },
            callback: function(success) {
                if (success) {
                    var form = card.lookupReference('assetsMainpanel');
                    dicvname.setValue([]);
                    dicvoperator.setValue([]);
                    dicvvalue.setValue([]);
                    card.getLayout().setActiveItem(form);
                }
            }
        });
    },
    onButtonAssetsBackClick: function() {
        var card = Bi.app.getComp('assetsMainView');
        var form = card.lookupReference('assetsMainpanel');
        var dicvform = card.lookupReference('assetsDicv');
        var dicvname = dicvform.lookupReference('assetsDicvName');
        var dicvoperator = dicvform.lookupReference('assetsDicvOperatorCombo');
        var dicvvalue = dicvform.lookupReference('assetsDicvValue');
        dicvname.setValue([]);
        dicvoperator.setValue([]);
        dicvvalue.setValue([]);
        card.getLayout().setActiveItem(form);
    }
});

/**
 * Created by max.neuhauser on 11.05.2017.
 */
Ext.define('Bi.view.assets.dicv.Model', {
    extend: Ext.app.ViewModel,
    alias: 'viewmodel.assetsDicvModel'
});

Ext.define('Bi.view.assets.main.Controller', {
    extend: Ext.app.ViewController,
    alias: 'controller.assetsMainController',
    initViewModel: function() {
        Bi.app.setComp('assetsMainView', this.getView());
    }
});

Ext.define('Bi.view.assets.main.Model', {
    extend: Ext.app.ViewModel,
    alias: 'viewmodel.assetsMainModel'
});

/**
 * Created by max.neuhauser on 31.03.2017.
 */
Ext.define('Bi.view.assets.mainpanel.Controller', {
    extend: Ext.app.ViewController,
    alias: 'controller.assetsMainpanelController',
    onDicvTagfieldExpand: function(field, eOpts) {
        var store = field.getStore();
        store.needloaded = true;
        Bi.app.expandTagfield(field, eOpts);
    },
    onChartRenderComboSelect: function(combo, record, eOpts) {
        var main = Bi.app.getComp('assetsMainView');
        var mainpanel = main.lookupReference('assetsMainpanel');
        var displayPanel = mainpanel.lookupReference('assetsDisplayPanel');
        var errorDisplay = mainpanel.lookupReference('assetsDisplayError');
        var gridPanel = mainpanel.lookupReference('assetsGridPanel');
        var chart = mainpanel.lookupReference('assetsColumnChart');
        var store = chart.getStore();
        displayPanel.setHidden(true);
        gridPanel.setHidden(true);
        errorDisplay.setHidden(true);
        store.load(function() {
            chart.redraw();
        });
    },
    onDicvComboSelect: function(combo, record, eOpts) {
        var main = Bi.app.getComp('assetsMainView');
        var mainpanel = main.lookupReference('assetsMainpanel');
        var displayPanel = mainpanel.lookupReference('assetsDisplayPanel');
        var errorDisplay = mainpanel.lookupReference('assetsDisplayError');
        var gridPanel = mainpanel.lookupReference('assetsGridPanel');
        var chart = mainpanel.lookupReference('assetsColumnChart');
        var store = chart.getStore();
        displayPanel.setHidden(true);
        gridPanel.setHidden(true);
        errorDisplay.setHidden(true);
        store.load(function() {
            chart.redraw();
        });
    },
    onDisplayComboSelect: function(combo, record, eOpts) {
        var main = Bi.app.getComp('assetsMainView');
        var mainpanel = main.lookupReference('assetsMainpanel');
        var displayPanel = mainpanel.lookupReference('assetsDisplayPanel');
        var errorDisplay = mainpanel.lookupReference('assetsDisplayError');
        var gridPanel = mainpanel.lookupReference('assetsGridPanel');
        var chartRenderCombo = mainpanel.lookupReference('assetsChartRenderCombo');
        var chart = mainpanel.lookupReference('assetsColumnChart');
        var store = chart.getStore();
        displayPanel.setHidden(true);
        gridPanel.setHidden(true);
        errorDisplay.setHidden(true);
        if (record.getData().value == 'chart') {
            chartRenderCombo.setDisabled(false);
        } else {
            chartRenderCombo.setDisabled(false);
        }
        store.load(function() {
            chart.redraw();
        });
    },
    onButtonDisplayClick: function(button, e, eOpts) {
        var main = Bi.app.getComp('assetsMainView');
        var mainpanel = main.lookupReference('assetsMainpanel');
        var dicvCombo = mainpanel.lookupReference('assetsDicvCombo');
        var displayCombo = mainpanel.lookupReference('assetsDisplayCombo');
        var displayPanel = mainpanel.lookupReference('assetsDisplayPanel');
        var errorDisplay = mainpanel.lookupReference('assetsDisplayError');
        var chartRenderCombo = mainpanel.lookupReference('assetsChartRenderCombo');
        var value = chartRenderCombo.getValue();
        var gridPanel = mainpanel.lookupReference('assetsGridPanel');
        switch (displayCombo.getValue()) {
            case 'chart':
                var chart = mainpanel.lookupReference('assetsColumnChart');
                var store = chart.getStore();
                store.load({
                    params: {
                        type: dicvCombo.getValue()
                    },
                    callback: function(records, operation, success) {
                        if (success) {
                            displayPanel.setTitle(dicvCombo.getValue());
                            displayPanel.setHidden(false);
                            gridPanel.setHidden(true);
                            errorDisplay.setHidden(true);
                        } else {
                            displayPanel.setHidden(true);
                            gridPanel.setHidden(true);
                            errorDisplay.setHidden(false);
                        }
                    }
                });
                break;
            case 'grid':
                var grid = mainpanel.lookupReference('assetsGridGrid');
                var storeGrid = grid.getStore();
                storeGrid.load({
                    params: {
                        type: dicvCombo.getValue(),
                        rendertype: value
                    },
                    callback: function(records, operation, success) {
                        if (success) {
                            gridPanel.setTitle(dicvCombo.getValue());
                            displayPanel.setHidden(true);
                            gridPanel.setHidden(false);
                            errorDisplay.setHidden(true);
                        } else {
                            displayPanel.setHidden(true);
                            gridPanel.setHidden(true);
                            errorDisplay.setHidden(false);
                        }
                    }
                });
                break;
        }
    },
    onButtonDicvClick: function(button, e, eOpts) {
        var card = Bi.app.getComp('assetsMainView');
        var form = card.lookupReference('assetsDicv');
        card.getLayout().setActiveItem(form);
    },
    onSeriesLabelRender: function(v) {
        var main = Bi.app.getComp('assetsMainView');
        var mainpanel = main.lookupReference('assetsMainpanel');
        var chartRenderCombo = mainpanel.lookupReference('assetsChartRenderCombo');
        var value = chartRenderCombo.getValue();
        switch (value) {
            case 'without':
                return Ext.util.Format.number(v, '0,000');
                break;
            case 'byte':
                return Ext.util.Format.number(v, '0,000 Byte');
                break;
            case 'kbyte':
                return Ext.util.Format.number(v / 1024, '0,000 KByte');
                break;
            case 'mbyte':
                return Ext.util.Format.number((v / 1024) / 1024, '0,000 MByte');
                break;
            case 'gbyte':
                return Ext.util.Format.number(((v / 1024) / 1024) / 1024, '0,000 GByte');
                break;
            default:
                return Ext.util.Format.number(v, '0,000');
                break;
        }
    },
    onAxisLabelRender: function(axis, label, layoutContext) {
        var main = Bi.app.getComp('assetsMainView');
        var view = main.lookupReference('assetsMainpanel');
        var chartRenderCombo = view.lookupReference('assetsChartRenderCombo');
        var value = chartRenderCombo.getValue();
        var chart = view.lookupReference('assetsColumnChart');
        var store = chart.getStore();
        var dataField = store.getData();
        if (dataField.items) {
            var maxValue = 0;
            for (var i = 0; i < dataField.items.length; i++) {
                if (Ext.isDefined(dataField.items[i])) {
                    var data = dataField.items[i].data.value;
                }
                if (data >= maxValue) {
                    maxValue = data;
                }
            }
            var ticks = layoutContext.majorTicks;
            if (maxValue < 10) {
                ticks.max = maxValue;
                ticks.step = 10;
                ticks.steps = maxValue;
                ticks.to = maxValue;
                ticks.unit.fixes = 0;
                ticks.unit.scale = 0.1;
            }
        }
        switch (value) {
            case 'without':
                return Ext.util.Format.number(layoutContext.renderer(label), '0,000');
                break;
            case 'byte':
                return Ext.util.Format.number(layoutContext.renderer(label), '0,000 Byte');
                break;
            case 'kbyte':
                return Ext.util.Format.number(layoutContext.renderer(label) / 1024, '0,000 KByte');
                break;
            case 'mbyte':
                return Ext.util.Format.number((layoutContext.renderer(label) / 1024) / 1024, '0,000 MByte');
                break;
            case 'gbyte':
                return Ext.util.Format.number(((layoutContext.renderer(label) / 1024) / 1024) / 1024, '0,000 GByte');
                break;
            default:
                return Ext.util.Format.number(layoutContext.renderer(label), '0,000');
                break;
        }
    }
});

/**
 * Created by max.neuhauser on 31.03.2017.
 */
Ext.define('Bi.view.assets.mainpanel.Model', {
    extend: Ext.app.ViewModel,
    alias: 'viewmodel.assetsMainpanelModel'
});

